package scdproject;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Frame setup
            JFrame frame = new JFrame("📇 Contact Manager");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(500, 500);
            frame.setLocationRelativeTo(null); // Center on screen

            // Main panel with padding and layout
            JPanel mainPanel = new JPanel(new GridBagLayout());
            mainPanel.setBorder(new EmptyBorder(15, 20, 15, 20));
            mainPanel.setBackground(new Color(245, 245, 245));

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            Font labelFont = new Font("Segoe UI", Font.PLAIN, 14);
            Font fieldFont = new Font("Segoe UI", Font.PLAIN, 13);

            // Name
            JLabel nameLabel = new JLabel("Name:");
            nameLabel.setFont(labelFont);
            TextField nameField = new TextField(20);
            nameField.setFont(fieldFont);

            // Phone
            JLabel phoneLabel = new JLabel("Phone:");
            phoneLabel.setFont(labelFont);
            TextField phoneField = new TextField(20);
            phoneField.setFont(fieldFont);

            // Email
            JLabel emailLabel = new JLabel("Email:");
            emailLabel.setFont(labelFont);
            TextField emailField = new TextField(20);
            emailField.setFont(fieldFont);

            // Add components to layout
            gbc.gridx = 0; gbc.gridy = 0;
            mainPanel.add(nameLabel, gbc);
            gbc.gridx = 1;
            mainPanel.add(nameField, gbc);

            gbc.gridx = 0; gbc.gridy = 1;
            mainPanel.add(phoneLabel, gbc);
            gbc.gridx = 1;
            mainPanel.add(phoneField, gbc);

            gbc.gridx = 0; gbc.gridy = 2;
            mainPanel.add(emailLabel, gbc);
            gbc.gridx = 1;
            mainPanel.add(emailField, gbc);

            // Buttons
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
            buttonPanel.setBackground(new Color(245, 245, 245));

            JButton addBtn = new JButton("➕ Add");
            JButton viewBtn = new JButton("📄 View All");
            JButton updateBtn = new JButton("✏️ Update");
            JButton deleteBtn = new JButton("🗑️ Delete");

            JButton[] buttons = {addBtn, viewBtn, updateBtn, deleteBtn};
            for (JButton btn : buttons) {
                btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
                btn.setBackground(new Color(100, 149, 237));
                btn.setForeground(Color.WHITE);
                btn.setFocusPainted(false);
            }

            buttonPanel.add(addBtn);
            buttonPanel.add(viewBtn);
            buttonPanel.add(updateBtn);
            buttonPanel.add(deleteBtn);

            gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
            mainPanel.add(buttonPanel, gbc);

            // Text area for view all
            TextArea viewAllTextArea = new TextArea(10, 35);
            viewAllTextArea.setFont(new Font("Consolas", Font.PLAIN, 13));
            viewAllTextArea.setEditable(false);

            JScrollPane scrollPane = new JScrollPane(viewAllTextArea);
            scrollPane.setBorder(BorderFactory.createTitledBorder("📋 Contact List"));

            gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
            mainPanel.add(scrollPane, gbc);

            // Initialize logic classes
            ArrayList<ContactManager_AddView.Contact> contactList = new ArrayList<>();
            ContactManager_AddView addView = new ContactManager_AddView(contactList, nameField, phoneField, emailField, viewAllTextArea);
            ContactManager_UpdateDelete updater = new ContactManager_UpdateDelete(contactList, nameField, phoneField, emailField);
            ContactManager_ValidationReplay validator = new ContactManager_ValidationReplay(frame, nameField, phoneField, emailField);

            // Button listeners
            addBtn.addActionListener(e -> {
                if (validator.validateInputs()) {
                    addView.handleAdd();
                    validator.showReplayOption();
                }
            });

            viewBtn.addActionListener(e -> addView.handleViewAll());
            updateBtn.addActionListener(e -> updater.handleUpdate());
            deleteBtn.addActionListener(e -> updater.handleDelete());

            frame.add(mainPanel);
            frame.setVisible(true);
        });
    }
}
