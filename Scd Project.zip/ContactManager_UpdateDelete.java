package scdproject;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import java.awt.TextField;

public class ContactManager_UpdateDelete {
    private ArrayList<ContactManager_AddView.Contact> contactList;
    private TextField nameField, phoneField, emailField;

    public ContactManager_UpdateDelete(ArrayList<ContactManager_AddView.Contact> contactList,
                                       TextField nameField, TextField phoneField, TextField emailField) {
        this.contactList = contactList;
        this.nameField = nameField;
        this.phoneField = phoneField;
        this.emailField = emailField;
    }

    public void handleUpdate() {
        String name = nameField.getText().trim();
        String phone = phoneField.getText().trim();
        String email = emailField.getText().trim();

        for (ContactManager_AddView.Contact c : contactList) {
            if (c.name.equalsIgnoreCase(name)) {
                c.phone = phone;
                c.email = email;
                JOptionPane.showMessageDialog(null, "Contact Updated!");
                return;
            }
        }

        JOptionPane.showMessageDialog(null, "Contact Not Found!");
    }

    public void handleDelete() {
        String name = nameField.getText().trim();
        boolean removed = contactList.removeIf(c -> c.name.equalsIgnoreCase(name));

        if (removed) {
            JOptionPane.showMessageDialog(null, "Contact Deleted!");
        } else {
            JOptionPane.showMessageDialog(null, "Contact Not Found!");
        }
    }
}
