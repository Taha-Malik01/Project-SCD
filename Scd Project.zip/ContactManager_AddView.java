package scdproject;
import java.util.ArrayList;
import java.awt.*;
import javax.swing.*;

public class ContactManager_AddView {
    private ArrayList<Contact> contactList;
    private TextField nameField, phoneField, emailField;
    private TextArea viewAllTextArea;

    public ContactManager_AddView(ArrayList<Contact> contactList,
                                  TextField nameField, TextField phoneField, TextField emailField,
                                  TextArea viewAllTextArea) {
        this.contactList = contactList;
        this.nameField = nameField;
        this.phoneField = phoneField;
        this.emailField = emailField;
        this.viewAllTextArea = viewAllTextArea;
    }

    public void handleAdd() {
        try {
            String name = nameField.getText().trim();
            String phone = phoneField.getText().trim();
            String email = emailField.getText().trim();

            Contact c = new Contact(name, phone, email);
            contactList.add(c);

            JOptionPane.showMessageDialog(null, "Contact Added!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error: Invalid input!");
        }
    }

    public void handleViewAll() {
        viewAllTextArea.setText("");
        for (Contact c : contactList) {
            viewAllTextArea.append(c.toString() + "\n");
        }
    }

    public static class Contact {
        String name, phone, email;

        public Contact(String name, String phone, String email) {
            this.name = name;
            this.phone = phone;
            this.email = email;
        }

        public String toString() {
            return "Name: " + name + " | Phone: " + phone + " | Email: " + email;
        }
    }
}
