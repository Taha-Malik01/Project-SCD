package scdproject;
import java.awt.TextField;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class ContactManager_ValidationReplay {
    private TextField nameField, phoneField, emailField;
    private JFrame frame;

    public ContactManager_ValidationReplay(JFrame frame,
                                           TextField nameField, TextField phoneField, TextField emailField) {
        this.frame = frame;
        this.nameField = nameField;
        this.phoneField = phoneField;
        this.emailField = emailField;
    }

    public boolean validateInputs() {
        String name = nameField.getText().trim();
        String phone = phoneField.getText().trim();
        String email = emailField.getText().trim();

        if (name.isEmpty() || !Pattern.matches("[a-zA-Z ]+", name)) {
            JOptionPane.showMessageDialog(frame, "Invalid name.");
            return false;
        }

        if (!Pattern.matches("^[0-9]{10,15}$", phone)) {
            JOptionPane.showMessageDialog(frame, "Invalid phone number. Should be 10–15 digits.");
            return false;
        }

        if (!Pattern.matches("^[\\w.-]+@[\\w.-]+\\.\\w+$", email)) {
            JOptionPane.showMessageDialog(frame, "Invalid email format.");
            return false;
        }

        return true;
    }

    public void showReplayOption() {
        int choice = JOptionPane.showConfirmDialog(
            frame,
            "Do you want to continue using the Contact Manager?",
            "Continue?",
            JOptionPane.YES_NO_OPTION
        );

        if (choice == JOptionPane.NO_OPTION) {
            System.exit(0);
        }
    }
}
